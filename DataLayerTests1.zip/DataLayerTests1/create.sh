#!/bin/bash

mkdir -p DataLayerSample/src/DataLayer DataLayerSample/tests/DataLayer.Tests
cd DataLayerSample
dotnet new sln -n DataLayerSample
dotnet new classlib -n DataLayer -o src/DataLayer
dotnet new xunit -n DataLayer.Tests -o tests/DataLayer.Tests
dotnet sln add src/DataLayer/DataLayer.csproj tests/DataLayer.Tests/DataLayer.Tests.csproj
dotnet add src/DataLayer package Microsoft.EntityFrameworkCore --version 8.*
dotnet add src/DataLayer package Microsoft.EntityFrameworkCore.Sqlite --version 8.*
dotnet add tests/DataLayer.Tests package Microsoft.EntityFrameworkCore --version 8.*
dotnet add tests/DataLayer.Tests package Microsoft.EntityFrameworkCore.Sqlite --version 8.*
dotnet add tests/DataLayer.Tests package FluentAssertions --version 6.*
dotnet add tests/DataLayer.Tests package coverlet.collector --version 6.*
dotnet add tests/DataLayer.Tests reference ../src/DataLayer/DataLayer.csproj

