using DataLayer.Abstractions;
using DataLayer.Infrastructure;
using DataLayer.Models;
using DataLayer.Tests.Fixtures;

namespace DataLayer.Tests.Repositories;

public class TodoRepositoryTests(SqliteInMemoryFixture f) : IClassFixture<SqliteInMemoryFixture>
{
    [Fact]
    public async Task Add_and_get_roundtrip()
    {
        await f.CleanAsync();
        using var db = f.CreateContext();
        ITodoRepository repo = new TodoRepository(db);

        var created = await repo.AddAsync(new TodoItem { Title = "write tests" });
        created.Id.Should().BeGreaterThan(0);

        var fetched = await repo.GetAsync(created.Id);
        fetched.Should().NotBeNull();
        fetched!.Title.Should().Be("write tests");
        fetched.IsDone.Should().BeFalse();
        fetched.CreatedUtc.Kind.Should().Be(DateTimeKind.Utc);
    }

    [Fact]
    public async Task ListOpen_returns_only_not_done_in_oldest_first_order()
    {
        await f.CleanAsync();
        using var db = f.CreateContext();
        ITodoRepository repo = new TodoRepository(db);

        await repo.AddAsync(new TodoItem { Title = "A", IsDone = false, CreatedUtc = DateTime.UtcNow.AddMinutes(-2) });
        await repo.AddAsync(new TodoItem { Title = "B", IsDone = true,  CreatedUtc = DateTime.UtcNow.AddMinutes(-1) });
        await repo.AddAsync(new TodoItem { Title = "C", IsDone = false, CreatedUtc = DateTime.UtcNow });

        var open = await repo.ListOpenAsync();
        open.Select(t => t.Title).Should().Equal("A", "C");
    }

    [Fact]
    public async Task Delete_returns_affected_row_count()
    {
        await f.CleanAsync();
        using var db = f.CreateContext();
        ITodoRepository repo = new TodoRepository(db);

        var item = await repo.AddAsync(new TodoItem { Title = "temp" });
        var rows = await repo.DeleteAsync(item.Id);
        rows.Should().Be(1);

        (await repo.GetAsync(item.Id)).Should().BeNull();
    }
}
