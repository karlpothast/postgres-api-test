using DataLayer.Infrastructure;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;

namespace DataLayer.Tests.Fixtures;

/// <summary>
/// One shared SQLite in-memory database per test class.
/// Each test gets a fresh DbContext and cleans tables to keep tests isolated.
/// </summary>
public class SqliteInMemoryFixture : IAsyncLifetime
{
    private SqliteConnection? _conn;
    private DbContextOptions<AppDbContext>? _options;

    public AppDbContext CreateContext() =>
        new(_options ?? throw new InvalidOperationException("Fixture not initialized"));

    public async Task InitializeAsync()
    {
        _conn = new SqliteConnection("DataSource=:memory:;Cache=Shared");
        await _conn.OpenAsync();

        _options = new DbContextOptionsBuilder<AppDbContext>()
            .UseSqlite(_conn)
            .EnableSensitiveDataLogging()
            .Options;

        using var db = new AppDbContext(_options);
        await db.Database.EnsureCreatedAsync();
    }

    public async Task DisposeAsync()
    {
        if (_conn is not null)
            await _conn.DisposeAsync();
    }

    public async Task CleanAsync()
    {
        using var db = new AppDbContext(_options!);
        await db.Database.ExecuteSqlRawAsync("DELETE FROM todos;");
    }
}
