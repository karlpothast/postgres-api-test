using DataLayer.Models;

namespace DataLayer.Abstractions;

public interface ITodoRepository
{
    Task<TodoItem> AddAsync(TodoItem item, CancellationToken ct = default);
    Task<TodoItem?> GetAsync(int id, CancellationToken ct = default);
    Task<IReadOnlyList<TodoItem>> ListOpenAsync(CancellationToken ct = default);
    Task<int> DeleteAsync(int id, CancellationToken ct = default);
}
