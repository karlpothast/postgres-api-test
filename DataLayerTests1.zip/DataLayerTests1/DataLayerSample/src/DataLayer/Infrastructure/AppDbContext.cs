using DataLayer.Models;
using Microsoft.EntityFrameworkCore;

namespace DataLayer.Infrastructure;

public class AppDbContext(DbContextOptions<AppDbContext> options) : DbContext(options)
{
    public DbSet<TodoItem> Todos => Set<TodoItem>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<TodoItem>(b =>
        {
            b.ToTable("todos");
            b.HasKey(x => x.Id);
            b.Property(x => x.Title).IsRequired().HasMaxLength(200);
            b.Property(x => x.CreatedUtc).HasConversion(
                v => v, v => DateTime.SpecifyKind(v, DateTimeKind.Utc)
            );
            b.HasIndex(x => new { x.IsDone, x.CreatedUtc });
        });
    }
}
