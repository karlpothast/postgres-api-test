using DataLayer.Abstractions;
using DataLayer.Models;
using Microsoft.EntityFrameworkCore;

namespace DataLayer.Infrastructure;

public class TodoRepository(AppDbContext db) : ITodoRepository
{
    public async Task<TodoItem> AddAsync(TodoItem item, CancellationToken ct = default)
    {
        await db.Todos.AddAsync(item, ct);
        await db.SaveChangesAsync(ct);
        return item;
    }

    public Task<TodoItem?> GetAsync(int id, CancellationToken ct = default) =>
        db.Todos.AsNoTracking().FirstOrDefaultAsync(t => t.Id == id, ct);

    public async Task<IReadOnlyList<TodoItem>> ListOpenAsync(CancellationToken ct = default) =>
        await db.Todos.AsNoTracking()
                      .Where(t => !t.IsDone)
                      .OrderBy(t => t.CreatedUtc)
                      .ToListAsync(ct);

    public async Task<int> DeleteAsync(int id, CancellationToken ct = default)
    {
        var rows = await db.Todos.Where(t => t.Id == id).ExecuteDeleteAsync(ct);
        return rows;
    }
}
